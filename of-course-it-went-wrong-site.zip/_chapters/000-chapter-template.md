---
title: Chapter Title
slug: chapter-title
category: Team dynamics
order: 999
status: draft
date: 2026-01-22
summary: One sentence describing the chapter.
---

### Vignette

Write a short, concrete story that shows the principle in action.

### The principle

Define the principle in plain language.

### Why it feels inevitable

- Bullet 1
- Bullet 2
- Bullet 3

### Examples

- **Work:** example
- **Home:** example
- **Society:** example

### How to spot it

- Sign 1
- Sign 2
- Sign 3

### How to counter it

- Countermeasure 1
- Countermeasure 2
- Countermeasure 3

### Reflective question

A single question the reader can sit with.
