---
layout: default
title: About
permalink: /about/
---

This site publishes chapters as they are written. Each chapter is a principle with a short vignette, a definition, examples, spotting signals, countermeasures, and a reflective question.

If you want to use this as a “book”, start with the categories and read in order. If you want a “blog”, read the latest chapters first.
